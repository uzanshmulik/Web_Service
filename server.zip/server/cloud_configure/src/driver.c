#include <string.h>
#include "files_utils.h"
#include "user_utils.h"
#include <stdlib.h>
#include <stdio.h>
#include "fcgi_stdio.h"

#define ADD_USER_REQUEST  "/adduser/"
#define DOWNLOAD_REQUEST  "/download/"
#define UPLOAD_REQUEST  "/upload/"

#define QUERY_STRING "QUERY_STRING"
#define SCRIPT_NAME "SCRIPT_NAME"

/* entry point */
int main()
{
	char name[50] = "";
	char password[129] = "";
	char file_name[50] = "";
	char *requset = NULL;

	while(FCGI_Accept() >= 0)
	 {
		printf("Content-type: text/html""\r\n\r\n");

		parsrQuery(getenv(QUERY_STRING), name, password, file_name);
		requset = getenv(SCRIPT_NAME);

		calcSHA1(password);

		if (strcmp(requset, ADD_USER_REQUEST) == 0)
		{	
			printf("Add user\n");
			if (addUser(name,password) == 0)
			{
				printf("User have been added\n");
			}
		}
		else if (strcmp(requset, DOWNLOAD_REQUEST) == 0)
		{	
//			printf("download\n");
			if(login(name, password) == 0)
			{
				sendfileToClient(name, file_name);
			}
		}
		else if (strcmp(requset, UPLOAD_REQUEST) == 0)
		{	
			printf("upload\n");
			if(login(name, password) == 0)
			{
				saveToFile(name, file_name);
			}
			else
			{
				printf("user or password is not match\n");
			}
		}
	}
	return 0;
}
