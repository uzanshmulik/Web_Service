#include "files_utils.h"
#include "fcgi_stdio.h"
#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>

#define BUF_SIZE 1024
#define CLOUD_PATH  "/home/shmueluzan/Desktop/cloud_project/core/cloud/"
 // "/home/osipovar/Desktop/cloud/"

int sendfileToClient(char *name, char *file_name)
{
	void *content;
	char file_path[120] = "";
	int read;
	FILE *fp;

	strcat(file_path, CLOUD_PATH);
	strcat(file_path, "/");
	strcat(file_path, name);
	strcat(file_path, "/");
	strcat(file_path, file_name);

	fp = fopen(file_path, "r");
	if (fp == NULL)
	{
		printf("Status:400\n");
		return 1;
	}

	content = malloc(BUF_SIZE);
	if (content == NULL)
	{
		printf("ERROR: Out of memory\n");
		return 1;
	}
	// printf("About to write\n");
	while ((read = fread(content, 1, BUF_SIZE, fp))) 
	{
	    // printf("Read %d bytes", read);
		fwrite(content, read, 1, stdout);
        // printf("Writing %d\n", read);
	}

	if (ferror(stdin))
	{
		printf("There was an error reading from stdin");
		return 1;
	}

    // printf("Done writing\n");
	free(content);
	fclose(fp);
	return 0;
}


int saveToFile(char *name, char *file_name)
{
	struct stat st = {0};
	char path[80] = "";
	char file_path[80] = "";
	FILE *fp;
	void *content;
	int read;

	strcat(path, CLOUD_PATH);
	strcat(path, name);

	//check if directory exists
	if(stat(path, &st) == -1){
		mkdir(path, 0700);
	}

	if (feof(stdin))
		printf("stdin reached eof\n");

	strcat(file_path, path);
	strcat(file_path, "/");
	strcat(file_path, file_name);

	
	fp = fopen(file_path, "w");
	if (fp == NULL)
	{
		printf("There was an error while trying to open the file.\n");
		return 1;
	}

	// printf("About to write\n");
	content = malloc(BUF_SIZE);
	if (content == NULL)
	{
		printf("ERROR: Out of memory\n");
		return 1;
	}
	while ((read = fread(content, 1, BUF_SIZE, stdin)))
	{
		printf("Read %d bytes\n", read);
		fwrite(content, read, 1, fp);
		printf("Writing %d\n", read);
	}

	if (ferror(stdin))
	{
		printf("There was an error reading from stdin");
		return 1;
	}
	// printf("Done writing\n");
	free(content);
	fclose(fp);	
	return 0;
}


void parsrQuery(char *query, char *name, char *password, char *file_name)
{
	char split = '&';
	int lenght_query = strlen(query);
	int i=0;
	int copy_name = 0;
	int copy_password = 0;
	int copy_file_name = 0;
	int num_params = 0;

	// printf("Query : %s \n", query);

	for(; i < lenght_query; i++)
	{
		if( num_params == 0)
		{
			name[copy_name] = query[i];
			copy_name++;
			if(query[i] == split)
			{
				num_params++;
				name[copy_name-1]= '\0';
			}
		}
		else if( num_params == 1)
		{
			password[copy_password] = query[i];
			copy_password++;
			if(query[i] == split)
			{
				num_params++;
				password[copy_password-1]= '\0';
			}
		}
		else if( num_params == 2)
		{
			file_name[copy_file_name] = query[i];
			copy_file_name++;
			if(query[i] == split)
			{
				num_params++;
				file_name[copy_file_name-1] = '\0';
			}
		}

	}
	// printf("Name : %s \nPassword : %s\nfile_name : %s\n",name,password,file_name);
}
