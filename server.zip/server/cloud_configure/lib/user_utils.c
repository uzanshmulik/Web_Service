#include "user_utils.h"
#include "fcgi_stdio.h"
#include <string.h>
#include <openssl/sha.h>

#define PATH "/home/shmueluzan/Desktop/cloud_project/core/users.txt"
// "/home/osipovar/Desktop/users.txt"

int login(char *name, char *pass)
{
	FILE *fp;
	char line[255];
	char cCurrent;
	int i = 0;

	fp = fopen(PATH, "r");
	if (fp == NULL)
	{
		printf("Status:400\n");
		return 1;
	}

	while( (cCurrent = fgetc(fp)) != EOF)
	{
		line[i++] = cCurrent;
		if ( cCurrent == '\n')
		{
			line[i-1] = '\0';
			// printf("name %s password %s line %s\n", name, password, line);
			if(user_exsist(name, pass, line) == 0)
			{
                // printf("user found: %s\n", line);
                fclose(fp);
				return 0;
			}
			i = 0;
		}
	}

	fclose(fp);
	return 1;
}

int addUser(char *name, char *pass)
{
	FILE *fp;

	if(login(name, pass) == 0)
	{
		printf("user : %s already exists.\n", name);
		return 1;
	}

	fp = (fopen(PATH, "a"));
	if (fp == NULL)
	{
		printf("Status:400\n");
		return 1;
	}

	fprintf(fp, "%s:%s:\n", name, pass);
	fclose(fp);
	return 0;
}

int user_exsist(char* username, char* pass, char *line)
{
	char name[50];
	char password[50];
	int len = strlen(line);
	int i=0, copy_name=0, copy_password=0;
	char split = ':';
	int num_par = 0;

	for(; i<len; i++)
	{

		if(num_par == 0)
		{
			name[copy_name] = line[i];
			copy_name ++;

			if(line[i] == split)
			{
				name[copy_name-1] = '\0';
				num_par++;
			}
		}
		else if(num_par == 1)
		{
			password[copy_password] = line[i];
			copy_password++;
			if(line[i] == split)
			{
				password[copy_password-1] = '\0';
				num_par++;
			}
		}
	}
//	printf("from line - name - %s, pass - %s\n", name, password);
//	printf("from query - name - %s, pass - %s\n\n", username, pass);
	if (strcmp(name, username) == 0 && strcmp(password, pass) == 0)
		return 0;
	else
		return 1; 
}

int calcSHA1(char *pass) 
{
    int i = 0;
    unsigned char temp[SHA_DIGEST_LENGTH];
    char buf[SHA_DIGEST_LENGTH*2];

    memset(buf, 0x0, SHA_DIGEST_LENGTH*2);
    memset(temp, 0x0, SHA_DIGEST_LENGTH);

    SHA1((unsigned char *)pass, strlen(pass), temp);

    for (i=0; i < SHA_DIGEST_LENGTH; i++) 
    {
        sprintf((char*)&(buf[i*2]), "%02x", temp[i]);

    }

    // printf("SHA1 of %s is %s\n", pass, buf);
    strcpy(pass, buf);
    // printf("%s\n",pass);
    return 0;
}
