int sendfileToClient(char *name, char *file_name);
int saveToFile(char *name, char *file_name);
void parsrQuery(char *query, char *name, char *password, char *file_name);