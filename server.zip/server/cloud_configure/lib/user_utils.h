int login(char *name, char *pass);
int addUser(char *name, char *pass);
int user_exsist(char *username, char *pass, char *line);
int calcSHA1(char *pass);